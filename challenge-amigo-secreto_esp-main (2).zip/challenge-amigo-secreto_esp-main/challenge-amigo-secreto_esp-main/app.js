// El principal objetivo de este desafío es fortalecer tus habilidades en lógica de programación. Aquí deberás desarrollar la lógica para resolver el problema.
let amigos = [];

document.addEventListener("DOMContentLoaded", () => {
    document.querySelector(".button-draw").disabled = true;
});
function agregarAmigo() {
    const input = document.getElementById("amigo");
    const nombre = input.value.trim();
    const listaAmigos = document.getElementById("listaAmigos");
    if (!/^[A-Za-zÁÉÍÓÚáéíóúÑñ]+$/.test(nombre)) {
        alert("Solo se permiten letras, sin números ni caracteres especiales.");
        return;
    }
    if (amigos.includes(nombre)) {
        alert("Este nombre ya ha sido agregado.");
        return;
    }
    amigos.push(nombre);
    const li = document.createElement("li");
    li.textContent = nombre;
    listaAmigos.appendChild(li);
    
    input.value = "";
    document.querySelector(".button-draw").disabled = amigos.length < 3;
}
function sortearAmigo() {
    if (amigos.length < 3) {
        document.querySelector("h2").textContent = "Necesitas al menos 3 amigos para sortear.";
        return;
    }
    const index = Math.floor(Math.random() * amigos.length);
    const amigoSeleccionado = amigos.splice(index, 1)[0];
    document.querySelector(".section-title").textContent = `El amigo seleccionado es ${amigoSeleccionado}`;
    actualizarLista();
    if (amigos.length < 3) {
        document.querySelector(".button-draw").disabled = true;
        
    }
}
function actualizarLista() {
    const listaAmigos = document.getElementById("listaAmigos");
    listaAmigos.innerHTML = "";
    amigos.forEach(nombre => {
        const li = document.createElement("li");
        li.textContent = nombre;
        listaAmigos.appendChild(li);
    });
}
